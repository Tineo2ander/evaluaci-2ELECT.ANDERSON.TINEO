# Landing Page

Landing Page desarrollado en HTML, CSS y Javascript

## Comparte

Si te gusto el proyecto compártelo con otros, esto es un Landing Page GRATUITO para la comunidad de [FRONT END CHILE](https://www.facebook.com/groups/FrontEndChile/) y el mundo.

## Colaborar

Si encuentras algún error, o mejor aún, deseas mejorar lo que ya está implementado, eres bienvenido a realizar cambios, pero cuidado, todos los cambios serán revisados y validados antes de ser subidos o actualizados.
